// HMS/SHMS: campaign-selected branches, centered geometry and acceptance; see docs/HMS_SHMS_REVIEW.md.
#include "../../spectrometer_root.h"
#include <TSystem.h>
#include <TString.h>
#include "TFile.h"
#include "TTree.h"
#include <TNtuple.h>
#include "TCanvas.h"
#include <iostream>
#include <fstream>
#include "TMath.h"
#include "TH1F.h"
#include <TH2.h>
#include <TCutG.h>
#include <TStyle.h>
#include <TGraph.h>
#include <TROOT.h>
#include <TMath.h>
#include <TLegend.h>
#include <TPaveLabel.h>
#include <TProfile.h>
#include <TPolyLine.h>
#include <TObjArray.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include<math.h>
#include <iostream>
#include <fstream>
using namespace std;

void plot_ytar_residuals(
  Int_t nrun,
  const char *inputTreeFile,
  const char *opticsMetadataFile,
  const char *outputDir,
  const char *tag
){
  hallc::Spectrometer spec;
  if (!hallc::loadSpectrometer(inputTreeFile, spec)) return;

gStyle->SetPalette(1,0);
 gStyle->SetOptStat(1000011);
 gStyle->SetOptFit(11);
 gStyle->SetTitleOffset(1.,"Y");
 gStyle->SetTitleOffset(.7,"X");
 gStyle->SetLabelSize(0.04,"XY");
 gStyle->SetTitleSize(0.06,"XY");
 gStyle->SetPadLeftMargin(0.12);
  const Int_t Number=3;
  Double_t Red[Number] = { 1.0,0.0,0.0};
  Double_t Blue[Number] = { 1.0,0.0,1.0};
  Double_t Green[Number] = { 0.0,1.0,0.0};
 Double_t Len[Number] = { 0.0,.5,1.0};
 Int_t nb=50;
 TColor::CreateGradientColorTable(Number,Len,Red,Green,Blue,nb);
  //
 TObjArray HList(0);
 //  
 TString  tnrun=Form("%d",nrun);
  //  Get info for that optics run
 // Separately approved existing-bug correction: ndelcut is the interval
 // count here, while the metadata field counts boundaries. Read exactly the
 // foil line and edge line so the next run cannot become a spurious edge.
 hallc::RunMetadata metadata;
 if (!hallc::loadRunMetadata(nrun,metadata,opticsMetadataFile)) return;
 if (!hallc::centeredSieveOnly(spec,metadata.sieveFlag)) return;
 const TString OpticsID=metadata.opticsId.c_str();
 const Int_t RunNum=nrun, NumFoil=metadata.foils.size();
 const Int_t SieveFlag=metadata.sieveFlag;
 const Double_t CentAngle=metadata.angle;
 const vector<Double_t> ztar_foil=metadata.foils;
 const vector<Double_t> delcut=metadata.edges;
 const Int_t ndelcut=delcut.size()-1;
 cout << "Metadata: " << NumFoil << " foils; " << delcut.size()
      << " delta boundaries; " << ndelcut << " intervals" << endl;

 //
   TString inputroot = inputTreeFile;
   TString outdir = outputDir;
   TString outtag = tag;
   gSystem->ExpandPathName(inputroot);
   gSystem->ExpandPathName(outdir);
   gSystem->mkdir(outdir, kTRUE);

   TString outputpdf  = Form("%s/%s_ytar_residuals", outdir.Data(), outtag.Data());
   TString outputpdf1 = Form("%s/%s_ytar_residuals_by_sieve", outdir.Data(), outtag.Data());
   TString outputpdf2 = Form("%s/%s_ytar_residuals_delta", outdir.Data(), outtag.Data());
   TString outputhist = Form("%s/%s_ytar_residuals.root", outdir.Data(), outtag.Data());

  

   TFile *hroot = TFile::Open(inputroot, "READ");
   if (!hroot || hroot->IsZombie()) {
     cout << "ERROR: cannot open fit tree file: " << inputroot << endl;
     return;
   }
   TTree *FitTree = (TTree*) hroot->Get("TFit");
   if (!FitTree) {
     cout << "ERROR: no TFit tree in: " << inputroot << endl;
     hroot->Close();
     return;
   }
   Double_t  ys,xtar,ztar,xptar,yptar,ytar,delta,xptarT,yptarT,ytarT,ztarT;
   Double_t xfp,xpfp,yfp,ypfp,ysieveT,ysieve,xsieve,xsieveT;
   FitTree->SetBranchAddress("ys",&ysieve);
   FitTree->SetBranchAddress("xs",&xsieve);
   FitTree->SetBranchAddress("ysT",&ysieveT);
   FitTree->SetBranchAddress("xsT",&xsieveT);
   FitTree->SetBranchAddress("xtar",&xtar);
   FitTree->SetBranchAddress("ztar",&ztar);
   FitTree->SetBranchAddress("xptar",&xptar);
 FitTree->SetBranchAddress("yptar",&yptar);
 FitTree->SetBranchAddress("ytar",&ytar);
   FitTree->SetBranchAddress("xptarT",&xptarT);
 FitTree->SetBranchAddress("yptarT",&yptarT);
 FitTree->SetBranchAddress("ytarT",&ytarT);
 FitTree->SetBranchAddress("ztarT",&ztarT);
 FitTree->SetBranchAddress("delta",&delta);
 FitTree->SetBranchAddress("xpfp",&xpfp);
 FitTree->SetBranchAddress("ypfp",&ypfp);
 FitTree->SetBranchAddress("xfp",&xfp);
 FitTree->SetBranchAddress("yfp",&yfp);
 //
  vector <Double_t> ys_cent;
  vector <Double_t> xs_cent;
  for (Int_t nys=0;nys<spec.ny;nys++) {
    Double_t ypos=spec.ys(nys);
    ys_cent.push_back(ypos);
    Double_t xpos=spec.xs(nys);
    xs_cent.push_back(xpos);
  }
 //
 //
  vector<vector<vector<TH1F*> > > hYDiff;
   vector<vector<TH1F*> > hYDiff_ztar;
  vector<vector<TH2F*> > hYDiff_YpTrue;
  vector<vector<TGraphErrors*> > gYDiff_YpTrue;
  vector<TGraphErrors*>  gYDiff_ztar_delta;
  vector<TH1F*> hYtar;
  vector<TH1F*> hZtar;
  vector<vector<vector<Double_t > > > hYDiff_mean;
  vector<vector<vector<Double_t > > > hYDiff_sigma;
  vector<vector<vector<Double_t > > > hYDiff_cent;
  vector<vector<vector<Double_t > > > hYDiff_centerr;
  vector<vector<Double_t > >  hYDiff_ztar_mean;
  vector<vector<Double_t > >  hYDiff_ztar_sigma;
  vector<vector<Double_t > >  hYDiff_ztar_cent;
  vector<vector<Double_t > >  hYDiff_ztar_centerr;
  
  hYDiff_YpTrue.resize(NumFoil);
  gYDiff_ztar_delta.resize(NumFoil);
  gYDiff_YpTrue.resize(NumFoil);
  hYDiff_ztar.resize(NumFoil);
  hYDiff.resize(NumFoil);
  hYDiff_mean.resize(NumFoil);
  hYDiff_sigma.resize(NumFoil);
  hYDiff_cent.resize(NumFoil);
  hYDiff_centerr.resize(NumFoil);
 hYDiff_ztar_mean.resize(NumFoil);
  hYDiff_ztar_sigma.resize(NumFoil);
  hYDiff_ztar_cent.resize(NumFoil);
  hYDiff_ztar_centerr.resize(NumFoil);
  hYtar.resize(NumFoil);
  hZtar.resize(NumFoil);
   for (Int_t nf=0;nf<NumFoil;nf++) {
  hYDiff_ztar[nf].resize(ndelcut);
  hYDiff_YpTrue[nf].resize(ndelcut);
  gYDiff_YpTrue[nf].resize(ndelcut);
  hYDiff[nf].resize(ndelcut);
  hYDiff_mean[nf].resize(ndelcut);
  hYDiff_sigma[nf].resize(ndelcut);
  hYDiff_cent[nf].resize(ndelcut);
  hYDiff_centerr[nf].resize(ndelcut);
  hYDiff_ztar_mean[nf].resize(ndelcut);
  hYDiff_ztar_sigma[nf].resize(ndelcut);
  hYDiff_ztar_cent[nf].resize(ndelcut);
  hYDiff_ztar_centerr[nf].resize(ndelcut);
   for (Int_t nd=0;nd<ndelcut;nd++) {
      hYDiff[nf][nd].resize(spec.ny);
      hYDiff_mean[nf][nd].resize(spec.ny);
      hYDiff_sigma[nf][nd].resize(spec.ny);
      hYDiff_cent[nf][nd].resize(spec.ny);
      hYDiff_centerr[nf][nd].resize(spec.ny);
   }}
   //
   /*  
    for (Int_t nf=0;nf<NumFoil;nf++) {
      hYtar[nf] = new TH1F(Form("hYtar_%d",nf),Form("Run %s Ztar %3.2f ; Ytar",tnrun.Data(),ztar_foil[nf]),100,-10.,10.);
        HList.Add(hYtar[nf]);
     hZtar[nf] = new TH1F(Form("hZtar_%d",nf),Form("Run %s Ztar %3.2f ; Ztar",tnrun.Data(),ztar_foil[nf]),100,-35.,35.);
        HList.Add(hZtar[nf]);
    for (Int_t nd=0;nd<ndelcut;nd++) {
      Double_t DelCent=(delcut[nd+1]+delcut[nd])/2;
      hYDiff_YpTrue[nf][nd]  = new TH2F(Form("hYDiff_YTrue_%d_DelCut_%d",nf,nd),Form("Run %s Ztar %3.2f DelCut %3.1f; Yptar_true (rad); Ytar_true - Ytar (mr) ",tnrun.Data(),ztar_foil[nf],DelCent),90,-.045,.045,50,-5.,5.);
        HList.Add(hYDiff_YpTrue[nf][nd]);
      hYDiff_ztar[nf][nd]  = new TH1F(Form("hYDiff_%d_DelCut_%d",nf,nd),Form("Run %s Ztar %3.2fDelCut %3.1f; Ytar_true - Ytar (cm)",tnrun.Data(),ztar_foil[nf],DelCent),50,-5.,5.);
        HList.Add(hYDiff_ztar[nf][nd]);
    for (Int_t ns=0;ns<spec.ny;ns++) {
      hYDiff[nf][nd][ns]  = new TH1F(Form("hYDiff_%d_DelCut_%d_Xs_%d",nf,nd,ns),Form("Run %s Ztar %3.2f Ys = %d DelCut %3.1f; Ytar_true - Ytar (cm)",tnrun.Data(),ztar_foil[nf],ns,DelCent),50,-5.,5.);
        HList.Add(hYDiff[nf][nd][ns]);
*/
 for (Int_t nf=0;nf<NumFoil;nf++) {
      hYtar[nf] = new TH1F(Form("hYtar_%d",nf),Form("Run %s Ztar %3.2f ; Ytar",tnrun.Data(),ztar_foil[nf]),100,-1.,1.);
        HList.Add(hYtar[nf]);
     hZtar[nf] = new TH1F(Form("hZtar_%d",nf),Form("Run %s Ztar %3.2f ; Ztar",tnrun.Data(),ztar_foil[nf]),100,-1.,1.);
        HList.Add(hZtar[nf]);
    for (Int_t nd=0;nd<ndelcut;nd++) {
      Double_t DelCent=(delcut[nd+1]+delcut[nd])/2;
      hYDiff_YpTrue[nf][nd]  = new TH2F(Form("hYDiff_YTrue_%d_DelCut_%d",nf,nd),Form("Run %s Ztar %3.2f DelCut %3.1f; Yptar_true (rad); Ytar_true - Ytar (mr) ",tnrun.Data(),ztar_foil[nf],DelCent),90,-.045,.045,100,-1.,1.);
        HList.Add(hYDiff_YpTrue[nf][nd]);
      hYDiff_ztar[nf][nd]  = new TH1F(Form("hYDiff_%d_DelCut_%d",nf,nd),Form("Run %s Ztar %3.2fDelCut %3.1f; Ytar_true - Ytar (cm)",tnrun.Data(),ztar_foil[nf],DelCent),100,-1.,1.);
        HList.Add(hYDiff_ztar[nf][nd]);
    for (Int_t ns=0;ns<spec.ny;ns++) {
      hYDiff[nf][nd][ns]  = new TH1F(Form("hYDiff_%d_DelCut_%d_Xs_%d",nf,nd,ns),Form("Run %s Ztar %3.2f Ys = %d DelCut %3.1f; Ytar_true - Ytar (cm)",tnrun.Data(),ztar_foil[nf],ns,DelCent),50,-1.,1.);
        HList.Add(hYDiff[nf][nd][ns]);

    }  }}
    //
    
 //
Long64_t nentries = FitTree->GetEntries();
 cout << " start loop " << nentries << endl;
	for (int i = 0; i < nentries; i++) {
      		FitTree->GetEntry(i);
    for (Int_t nf=0;nf<NumFoil;nf++) {
      if (abs(ztarT-ztar_foil[nf])<2) { 
       for (Int_t nd=0;nd<ndelcut;nd++) {
	 if ( delta >=delcut[nd] && delta <delcut[nd+1]) {
	hYtar[nf]->Fill(ytar);
	hZtar[nf]->Fill(ztar);
	   hYDiff_YpTrue[nf][nd]->Fill(yptarT,(ytar-ytarT-.035));
            hYDiff_ztar[nf][nd]->Fill((ytar-ytarT+.035));
           for (Int_t ns=0;ns<spec.ny;ns++) {
	     if ( abs(ysieveT-ys_cent[ns])<.5) hYDiff[nf][nd][ns]->Fill((ytar-ytarT));
	   }
	 }
       }
    }
    }		
    //	
	}
	//
	TCanvas* can2d[NumFoil];
        Int_t colind=1;
	for  (Int_t nc=0;nc<NumFoil;nc++) {
	  can2d[nc] = new TCanvas(Form("Can2d_%d",nc),Form("Foil %d",nc), 700,700);
	  can2d[nc]->Divide(2,5);
	for  (Int_t nd=0;nd<ndelcut;nd++) {
	  can2d[nc]->cd(nd+1);
	  //	  hYDiff_YpTrue[nc][nd]->Draw("colz");
                 Double_t DelCent=(delcut[nd+1]+delcut[nd])/2;
	 	  hYDiff_ztar[nc][nd]->Draw("colz");
		  hYDiff_ztar_mean[nc][nd]= hYDiff_ztar[nc][nd]->GetMean();
	     hYDiff_ztar_sigma[nc][nd]= hYDiff_ztar[nc][nd]->GetRMS();
	     hYDiff_ztar_cent[nc][nd]= DelCent;
	     hYDiff_ztar_centerr[nc][nd]= 0.0001;
	}
	gYDiff_ztar_delta[nc] = new TGraphErrors(ndelcut,&hYDiff_ztar_cent[nc][0],&hYDiff_ztar_mean[nc][0],&hYDiff_ztar_centerr[nc][0],&hYDiff_ztar_sigma[nc][0]);
	if (colind==5) colind++;
	   gYDiff_ztar_delta[nc]->SetMarkerColor(colind++);
	   gYDiff_ztar_delta[nc]->SetMarkerStyle(nc+20);
	  TString end = ".pdf";
	  if (nc==0) end=".pdf(";
	  if (nc==NumFoil-1) end=".pdf)";
	  can2d[nc]->Print(outputpdf+end);

	}  //
	//
	TCanvas* candelta;
        TMultiGraph *mgrdelta;
        TLegend *legdelta;
		  candelta = new TCanvas("candelta","candelta", 700,700);
	  	  candelta->Divide(1,1);
	candelta->cd(1);
		  legdelta = new TLegend(.79,.65,.99,.95,"");
		 mgrdelta=new TMultiGraph();  
	for  (Int_t nf=0;nf<NumFoil;nf++) {
	  mgrdelta->Add(gYDiff_ztar_delta[nf]);
      legdelta->AddEntry(gYDiff_ztar_delta[nf],Form("Ztar = %3.1f",ztar_foil[nf]),"p");
	    }
	mgrdelta->SetTitle(Form("Spectrometer Angle = %4.2f; Delta ; Ytar -Y_true (cm)",CentAngle));
	mgrdelta->SetMinimum(-2);
	mgrdelta->SetMaximum(+2);
	mgrdelta->Draw("AP");
	legdelta->Draw();
	  TString end = ".pdf";
	  candelta->Print(outputpdf2+end);

	//	TCanvas* candel[NumFoil][ndelcut];
	Double_t Y_offset=0.; // Offset to get delta = 0 ztar=0 to about zero.
	for  (Int_t nf=0;nf<NumFoil;nf++) {
	  Int_t colind = 0;
	for  (Int_t nd=0;nd<ndelcut;nd++) {
	  //	  candel[nf][nd] = new TCanvas(Form("Candel_%d_%d",nf,nd),Form("Candel_%d_%d",nf,nd), 700,700);
	  //	  candel[nf][nd]->Divide(2,5);
           for (Int_t ns=0;ns<spec.ny;ns++) {
	     //   candel[nf][nd]->cd(ns+1);
	     //  hYDiff[nf][nd][ns]->Draw();
	     hYDiff_mean[nf][nd][ns]= hYDiff[nf][nd][ns]->GetMean()-Y_offset;
	     hYDiff_sigma[nf][nd][ns]= hYDiff[nf][nd][ns]->GetRMS();
	     hYDiff_cent[nf][nd][ns]= ys_cent[ns];
	     hYDiff_centerr[nf][nd][ns]= 0.0001;
	   }
	   gYDiff_YpTrue[nf][nd] = new TGraphErrors(spec.ny,&hYDiff_cent[nf][nd][0],&hYDiff_mean[nf][nd][0],&hYDiff_centerr[nf][nd][0],&hYDiff_sigma[nf][nd][0]);
	   colind++;
	   if (colind==5) colind++;
	   if (colind==8) colind=1;
	   gYDiff_YpTrue[nf][nd]->SetMarkerColor(colind);
	   gYDiff_YpTrue[nf][nd]->SetMarkerStyle(nd+20);
	}}	  
 gStyle->SetPadRightMargin(0.2);
        
 //
	TCanvas* candel[NumFoil];
        TMultiGraph *mgr[NumFoil];
        TLegend *leg[NumFoil];
	for  (Int_t nf=0;nf<NumFoil;nf++) {
		  candel[nf] = new TCanvas(Form("Candel_%d",nf),Form("Candel_%d",nf), 700,700);
	  	  candel[nf]->Divide(1,1);
		  leg[nf] = new TLegend(.79,.65,.99,.95,"");
		 mgr[nf]=new TMultiGraph();  
	for  (Int_t nd=0;nd<ndelcut;nd++) {
	  mgr[nf]->Add(gYDiff_YpTrue[nf][nd]);
      Double_t DelCent=(delcut[nd+1]+delcut[nd])/2;
      leg[nf]->AddEntry(gYDiff_YpTrue[nf][nd],Form("Delta = %3.1f",DelCent),"p");
	    }
	candel[nf]->cd(1);
	mgr[nf]->SetTitle(Form("Ztar = %4.1f Spectrometer Angle = %4.2f; Y_sieve (cm); Ytar -Y_true (cm)",ztar_foil[nf],CentAngle));
	mgr[nf]->SetMinimum(-5);
	mgr[nf]->SetMaximum(+5);
	mgr[nf]->Draw("AP");
	leg[nf]->Draw();
	  TString end = ".pdf";
	  if (nf==0) end=".pdf(";
	  if (nf==NumFoil-1) end=".pdf)";
	  candel[nf]->Print(outputpdf1+end);
	}
	//
 TFile hsimc(outputhist,"recreate");
	HList.Write();

//
}
